// JavaScript to trigger fade-in effect when element's bottom is close to the viewport top
document.addEventListener("DOMContentLoaded", function() {
    var fadeIns = document.querySelectorAll('.fade-in');
    
    function fadeInOnScroll() {
        fadeIns.forEach(function(fadeIn) {
            var bounding = fadeIn.getBoundingClientRect();
            if (
                bounding.bottom >= 0 &&
                bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight)
            ) {
                fadeIn.classList.add('visible');
            } else {
                fadeIn.classList.remove('visible');
            }
        });
    }

    fadeInOnScroll(); // Initial check
    window.addEventListener('scroll', fadeInOnScroll);
});